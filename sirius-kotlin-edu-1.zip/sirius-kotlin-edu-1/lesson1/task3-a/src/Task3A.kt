/**
 * Объявите класс IntPair1 такой, чтобы он
 *    - содержал неявные методы hashCode(), equals(), toString(), component1(), component2() и copy()
 *    - содержал неизменяемые свойства valueX и valueY типа Int
 *    - конструктор без параметров (valueX и valueY инициализируются значениями -1)
 *    - конструктор с двумя параметрами - valueX и valueY
 */
class IntPair1